<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>My Assignments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>My Assignments (${openAssignments.size()} / ${maxAssignments})</h2>
    <a href="${pageContext.request.contextPath}/CatalogueController"
       class="btn btn-secondary mb-3">&larr; Catalogue</a>

    <c:if test="${not empty error}">
        <div class="alert alert-danger"><c:out value="${error}"/></div>
    </c:if>

    <h4>Current Assignments</h4>
    <table class="table table-bordered mb-4">
        <tr><th>Flight</th><th>Role</th><th>Assigned On</th><th>Action</th></tr>
        <c:forEach var="a" items="${openAssignments}">
            <tr>
                <td><c:out value="${a.flightNumber}"/></td>
                <td><c:out value="${a.roleOnFlight}"/></td>
                <td><c:out value="${a.assignedOn}"/></td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/AssignmentController">
                        <input type="hidden" name="action" value="complete">
                        <input type="hidden" name="staffId" value="${staff.staffId}">
                        <input type="hidden" name="assignmentId" value="${a.assignmentId}">
                        <button class="btn btn-sm btn-warning">Complete</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty openAssignments}">
            <tr><td colspan="4">No current assignments.</td></tr>
        </c:if>
    </table>

    <h4>Assignment History</h4>
    <table class="table table-bordered">
        <tr><th>Flight</th><th>Role</th><th>Assigned</th><th>Status</th><th>Completed</th></tr>
        <c:forEach var="h" items="${history}">
            <tr>
                <td><c:out value="${h.flightNumber}"/></td>
                <td><c:out value="${h.roleOnFlight}"/></td>
                <td><c:out value="${h.assignedOn}"/></td>
                <td><c:out value="${h.status}"/></td>
                <td><c:out value="${h.completedOn}"/></td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>