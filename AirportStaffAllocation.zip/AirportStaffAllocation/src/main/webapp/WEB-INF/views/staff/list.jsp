<%--
  Created by IntelliJ IDEA.
  User: _.Spojxh
  Date: 11/13/2026
  Time: 9:52 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Staff</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Manage Staff</h2>
    <a href="${pageContext.request.contextPath}/CatalogueController"
       class="btn btn-secondary mb-3">&larr; Catalogue</a>
    <a href="?action=add" class="btn btn-success mb-3">Add Staff</a>

    <form method="get" class="d-flex mb-3">
        <input class="form-control me-2" name="q" placeholder="Search staff..."
               value="${param.q}">
        <button class="btn btn-primary">Search</button>
    </form>

    <table class="table table-striped">
        <tr>
            <th>Staff No</th><th>Name</th><th>Email</th>
            <th>Role</th><th>Department</th><th>Status</th><th>Actions</th>
        </tr>
        <c:forEach var="s" items="${staffList}">
            <tr>
                <td><c:out value="${s.staffNumber}"/></td>
                <td><c:out value="${s.fullName}"/></td>
                <td><c:out value="${s.email}"/></td>
                <td><c:out value="${s.role}"/></td>
                <td><c:out value="${s.department}"/></td>
                <td><c:out value="${s.status}"/></td>
                <td>
                    <a href="?action=edit&id=${s.staffId}" class="btn btn-sm btn-primary">Edit</a>
                    <a href="?action=delete-confirm&id=${s.staffId}" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>
