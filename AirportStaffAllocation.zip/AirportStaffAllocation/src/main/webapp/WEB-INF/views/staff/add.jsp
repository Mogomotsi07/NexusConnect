<%--
  Created by IntelliJ IDEA.
  User: _.Spojxh
  Date: 11/13/2026
  Time: 9:52 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Staff</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4" style="max-width: 600px;">
    <h2>Add Staff</h2>
    <a href="?action=list" class="btn btn-secondary mb-3">&larr; Back</a>

    <c:if test="${not empty errors}">
        <div class="alert alert-danger">
            <ul><c:forEach var="e" items="${errors}"><li><c:out value="${e.value}"/></li></c:forEach></ul>
        </div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/StaffManagementController">
        <input type="hidden" name="action" value="create">
        <div class="mb-3"><label>Staff Number</label>
            <input type="text" name="staffNumber" class="form-control" required></div>
        <div class="mb-3"><label>Full Name</label>
            <input type="text" name="fullName" class="form-control" required></div>
        <div class="mb-3"><label>Email</label>
            <input type="email" name="email" class="form-control" required></div>
        <div class="mb-3"><label>Phone</label>
            <input type="text" name="phone" class="form-control"></div>
        <div class="mb-3"><label>Role</label>
            <input type="text" name="role" class="form-control"
                   placeholder="Pilot / Cabin Crew / Ground Ops" required></div>
        <div class="mb-3"><label>Department</label>
            <input type="text" name="department" class="form-control" required></div>
        <div class="mb-3"><label>Status</label>
            <select name="status" class="form-select">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select></div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
</body>
</html>
