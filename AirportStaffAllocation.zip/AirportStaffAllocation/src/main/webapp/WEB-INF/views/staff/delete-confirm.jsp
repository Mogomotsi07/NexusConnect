<%--
  Created by IntelliJ IDEA.
  User: _.Spojxh
  Date: 11/13/2026
  Time: 9:53 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Confirm Delete</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="alert alert-danger">
        <h4>Confirm Deletion</h4>
        <p>Are you sure you want to delete <strong><c:out value="${staff.fullName}"/></strong>?</p>
    </div>
    <form method="post" action="${pageContext.request.contextPath}/StaffManagementController">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="${staff.staffId}">
        <button type="submit" class="btn btn-danger">Yes, Delete</button>
        <a href="?action=list" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>