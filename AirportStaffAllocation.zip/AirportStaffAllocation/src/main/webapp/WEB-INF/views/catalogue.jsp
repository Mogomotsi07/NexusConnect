<%--
  Created by IntelliJ IDEA.
  User: _.Spojxh
  Date: 11/13/2026
  Time: 9:50 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html>
<head>
    <title>Flight Catalogue</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-between mb-3">
        <h2>Flight Catalogue</h2>
        <div>
            <c:if test="${pageContext.request.isUserInRole('manager')}">
                <a href="${pageContext.request.contextPath}/StaffManagementController"
                   class="btn btn-sm btn-warning">Staff</a>
                <a href="${pageContext.request.contextPath}/FlightManagementController"
                   class="btn btn-sm btn-warning">Flights</a>
            </c:if>
            <c:if test="${pageContext.request.isUserInRole('staff')}">
                <a href="${pageContext.request.contextPath}/MyAssignmentsController"
                   class="btn btn-sm btn-info">My Assignments</a>
            </c:if>
            <a href="${pageContext.request.contextPath}/LogoutServlet"
               class="btn btn-sm btn-danger">Logout</a>
        </div>
    </div>

    <form class="d-flex mb-4" method="get"
          action="${pageContext.request.contextPath}/CatalogueController">
        <input class="form-control me-2" type="search" name="q"
               value="${fn:escapeXml(param.q)}" placeholder="Search flights...">
        <button class="btn btn-primary" type="submit">Search</button>
    </form>

    <c:if test="${not empty sessionScope.errorMsg}">
        <div class="alert alert-danger">${sessionScope.errorMsg}</div>
        <c:remove var="errorMsg" scope="session"/>
    </c:if>

    <table class="table table-striped">
        <tr>
            <th>Flight</th><th>Route</th><th>Date</th>
            <th>Depart</th><th>Arrive</th><th>Status</th>
            <th>Required Crew</th><th>Action</th>
        </tr>
        <c:forEach var="f" items="${flights}">
            <tr>
                <td><c:out value="${f.flightNumber}"/></td>
                <td><c:out value="${f.origin}"/> &rarr; <c:out value="${f.destination}"/></td>
                <td><c:out value="${f.departureDate}"/></td>
                <td><c:out value="${f.departureTime}"/></td>
                <td><c:out value="${f.arrivalTime}"/></td>
                <td><span class="badge bg-info"><c:out value="${f.status}"/></span></td>
                <td><c:out value="${f.requiredCrew}"/></td>
                <td>
                    <c:if test="${f.status == 'Scheduled'}">
                        <form method="post"
                              action="${pageContext.request.contextPath}/AssignmentController"
                              class="d-flex">
                            <input type="hidden" name="action" value="create">
                            <input type="hidden" name="flightId" value="${f.flightId}">
                            <input type="text" name="staffId" placeholder="Staff ID"
                                   class="form-control form-control-sm me-1" required>
                            <input type="text" name="roleOnFlight" placeholder="Role"
                                   class="form-control form-control-sm me-1" required>
                            <button class="btn btn-sm btn-primary">Assign</button>
                        </form>
                    </c:if>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>
