<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Flights</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Manage Flights</h2>
    <a href="${pageContext.request.contextPath}/CatalogueController"
       class="btn btn-secondary mb-3">&larr; Catalogue</a>
    <a href="?action=add" class="btn btn-success mb-3">Add Flight</a>

    <form method="get" class="d-flex mb-3">
        <input class="form-control me-2" name="q" placeholder="Search flights..."
               value="${param.q}">
        <button class="btn btn-primary">Search</button>
    </form>

    <table class="table table-striped">
        <tr>
            <th>Flight No</th><th>Route</th><th>Date</th>
            <th>Depart</th><th>Arrive</th><th>Status</th>
            <th>Required Crew</th><th>Actions</th>
        </tr>
        <c:forEach var="f" items="${flights}">
            <tr>
                <td><c:out value="${f.flightNumber}"/></td>
                <td><c:out value="${f.origin}"/> &rarr; <c:out value="${f.destination}"/></td>
                <td><c:out value="${f.departureDate}"/></td>
                <td><c:out value="${f.departureTime}"/></td>
                <td><c:out value="${f.arrivalTime}"/></td>
                <td><c:out value="${f.status}"/></td>
                <td><c:out value="${f.requiredCrew}"/></td>
                <td>
                    <a href="?action=edit&id=${f.flightId}" class="btn btn-sm btn-primary">Edit</a>
                    <a href="?action=delete-confirm&id=${f.flightId}" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>