<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Flight</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4" style="max-width: 600px;">
    <h2>Add Flight</h2>
    <a href="?action=list" class="btn btn-secondary mb-3">&larr; Back</a>

    <c:if test="${not empty errors}">
        <div class="alert alert-danger">
            <ul><c:forEach var="e" items="${errors}"><li><c:out value="${e.value}"/></li></c:forEach></ul>
        </div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/FlightManagementController">
        <input type="hidden" name="action" value="create">
        <div class="mb-3"><label>Flight Number</label>
            <input type="text" name="flightNumber" class="form-control" required></div>
        <div class="mb-3"><label>Origin</label>
            <input type="text" name="origin" class="form-control" required></div>
        <div class="mb-3"><label>Destination</label>
            <input type="text" name="destination" class="form-control" required></div>
        <div class="mb-3"><label>Departure Date</label>
            <input type="date" name="departureDate" class="form-control" required></div>
        <div class="mb-3"><label>Departure Time</label>
            <input type="time" name="departureTime" class="form-control" required></div>
        <div class="mb-3"><label>Arrival Time</label>
            <input type="time" name="arrivalTime" class="form-control" required></div>
        <div class="mb-3"><label>Status</label>
            <select name="status" class="form-select">
                <option value="Scheduled">Scheduled</option>
                <option value="Cancelled">Cancelled</option>
                <option value="Departed">Departed</option>
                <option value="Arrived">Arrived</option>
            </select></div>
        <div class="mb-3"><label>Required Crew</label>
            <input type="number" name="requiredCrew" class="form-control" min="1" value="1" required></div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
</body>
</html>