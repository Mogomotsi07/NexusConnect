<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Flight</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4" style="max-width: 600px;">
    <h2>Edit Flight</h2>
    <a href="?action=list" class="btn btn-secondary mb-3">&larr; Back</a>

    <c:if test="${not empty errors}">
        <div class="alert alert-danger">
            <ul><c:forEach var="e" items="${errors}"><li><c:out value="${e.value}"/></li></c:forEach></ul>
        </div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/FlightManagementController">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="${flight.flightId}">
        <div class="mb-3"><label>Flight Number</label>
            <input type="text" name="flightNumber" class="form-control" value="${flight.flightNumber}"></div>
        <div class="mb-3"><label>Origin</label>
            <input type="text" name="origin" class="form-control" value="${flight.origin}"></div>
        <div class="mb-3"><label>Destination</label>
            <input type="text" name="destination" class="form-control" value="${flight.destination}"></div>
        <div class="mb-3"><label>Departure Date</label>
            <input type="date" name="departureDate" class="form-control" value="${flight.departureDate}"></div>
        <div class="mb-3"><label>Departure Time</label>
            <input type="time" name="departureTime" class="form-control" value="${flight.departureTime}"></div>
        <div class="mb-3"><label>Arrival Time</label>
            <input type="time" name="arrivalTime" class="form-control" value="${flight.arrivalTime}"></div>
        <div class="mb-3"><label>Status</label>
            <select name="status" class="form-select">
                <option value="Scheduled" ${flight.status == 'Scheduled' ? 'selected' : ''}>Scheduled</option>
                <option value="Cancelled" ${flight.status == 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                <option value="Departed" ${flight.status == 'Departed' ? 'selected' : ''}>Departed</option>
                <option value="Arrived" ${flight.status == 'Arrived' ? 'selected' : ''}>Arrived</option>
            </select></div>
        <div class="mb-3"><label>Required Crew</label>
            <input type="number" name="requiredCrew" class="form-control"
                   min="1" value="${flight.requiredCrew}"></div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>