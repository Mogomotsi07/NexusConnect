<%--
  Created by IntelliJ IDEA.
  User: _.Spojxh
  Date: 11/13/2026
  Time: 9:49 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head><title>Login Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light text-center mt-5">
<h2 class="text-danger">Invalid username or password.</h2>
<a href="login.jsp" class="btn btn-primary mt-3">Try Again</a>
</body>
</html>
