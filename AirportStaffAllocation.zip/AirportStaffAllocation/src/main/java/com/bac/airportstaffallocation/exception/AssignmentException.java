package com.bac.airportstaffallocation.exception;

public class AssignmentException extends Exception {
    public AssignmentException(String message) {
        super(message);
    }
}