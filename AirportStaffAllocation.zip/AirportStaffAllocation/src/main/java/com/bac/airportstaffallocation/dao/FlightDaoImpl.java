package com.bac.airportstaffallocation.dao;

import com.bac.airportstaffallocation.config.DataSourceHelper;
import com.bac.airportstaffallocation.dao.FlightDao;
import com.bac.airportstaffallocation.model.Flight;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlightDaoImpl implements FlightDao {

    private Flight map(ResultSet rs) throws SQLException {
        Flight f = new Flight();
        f.setFlightId(rs.getInt("flight_id"));
        f.setFlightNumber(rs.getString("flight_number"));
        f.setOrigin(rs.getString("origin"));
        f.setDestination(rs.getString("destination"));
        f.setDepartureDate(rs.getDate("departure_date"));
        f.setDepartureTime(rs.getTime("departure_time"));
        f.setArrivalTime(rs.getTime("arrival_time"));
        f.setStatus(rs.getString("status"));
        f.setRequiredCrew(rs.getInt("required_crew"));
        return f;
    }

    @Override
    public List<Flight> findAll() {
        List<Flight> list = new ArrayList<>();
        String sql = "SELECT * FROM flights ORDER BY departure_date, departure_time";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public Flight findById(int id) {
        String sql = "SELECT * FROM flights WHERE flight_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public Flight findByFlightNumber(String flightNumber) {
        String sql = "SELECT * FROM flights WHERE flight_number=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, flightNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Flight> search(String keyword) {
        List<Flight> list = new ArrayList<>();
        String sql = "SELECT * FROM flights WHERE flight_number LIKE ? OR origin LIKE ? OR destination LIKE ? ORDER BY departure_date";
        String like = "%" + keyword + "%";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public void create(Flight f) {
        String sql = "INSERT INTO flights (flight_number, origin, destination, departure_date, departure_time, arrival_time, status, required_crew) " +
                "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, f.getFlightNumber());
            ps.setString(2, f.getOrigin());
            ps.setString(3, f.getDestination());
            ps.setDate(4, f.getDepartureDate());
            ps.setTime(5, f.getDepartureTime());
            ps.setTime(6, f.getArrivalTime());
            ps.setString(7, f.getStatus());
            ps.setInt(8, f.getRequiredCrew());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void update(Flight f) {
        String sql = "UPDATE flights SET flight_number=?, origin=?, destination=?, departure_date=?, departure_time=?, arrival_time=?, status=?, required_crew=? WHERE flight_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, f.getFlightNumber());
            ps.setString(2, f.getOrigin());
            ps.setString(3, f.getDestination());
            ps.setDate(4, f.getDepartureDate());
            ps.setTime(5, f.getDepartureTime());
            ps.setTime(6, f.getArrivalTime());
            ps.setString(7, f.getStatus());
            ps.setInt(8, f.getRequiredCrew());
            ps.setInt(9, f.getFlightId());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM flights WHERE flight_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public int countOpenAssignments(int flightId) {
        String sql = "SELECT COUNT(*) FROM assignments WHERE flight_id=? AND status='OPEN'";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return 0;
    }
}