package com.bac.airportstaffallocation.service;

import com.bac.airportstaffallocation.dao.FlightDao;
import com.bac.airportstaffallocation.dao.FlightDaoImpl;
import com.bac.airportstaffallocation.exception.ValidationException;
import com.bac.airportstaffallocation.model.Flight;

public class FlightService {

    private final FlightDao flightDao = new FlightDaoImpl();

    public void validateAndCreate(Flight f) throws ValidationException {
        validateCommon(f);
        flightDao.create(f);
    }

    public void validateAndUpdate(Flight f) throws ValidationException {
        validateCommon(f);
        flightDao.update(f);
    }

    public void delete(int flightId) throws ValidationException {
        Flight f = flightDao.findById(flightId);
        if (f == null) throw new ValidationException("error", "Flight not found.");

        if (flightDao.countOpenAssignments(flightId) > 0) {
            throw new ValidationException("error",
                    f.getFlightNumber() + " cannot be deleted — it has open staff assignments.");
        }
        flightDao.delete(flightId);
    }

    private void validateCommon(Flight f) throws ValidationException {
        if (f.getFlightNumber() == null || f.getFlightNumber().isBlank())
            throw new ValidationException("flightNumber", "Flight number is required.");
        if (f.getOrigin() == null || f.getOrigin().isBlank())
            throw new ValidationException("origin", "Origin is required.");
        if (f.getDestination() == null || f.getDestination().isBlank())
            throw new ValidationException("destination", "Destination is required.");
        if (f.getDepartureDate() == null)
            throw new ValidationException("departureDate", "Departure date is required.");
        if (f.getDepartureTime() == null || f.getArrivalTime() == null)
            throw new ValidationException("departureTime", "Departure and arrival times are required.");
        if (f.getRequiredCrew() < 1)
            throw new ValidationException("requiredCrew", "Required crew must be at least 1.");

        Flight existing = flightDao.findByFlightNumber(f.getFlightNumber());
        if (existing != null && existing.getFlightId() != f.getFlightId())
            throw new ValidationException("flightNumber", "Flight number already exists.");
    }
}