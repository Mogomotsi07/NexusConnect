package com.bac.airportstaffallocation.model;

import java.sql.Time;
import java.sql.Date;

public class Flight {
    private int flightId;
    private String flightNumber;
    private String origin;
    private String destination;
    private Date departureDate;
    private Time departureTime;
    private Time arrivalTime;
    private String status;  // Scheduled / Cancelled / Departed / Arrived
    private int requiredCrew;

    public Flight() {}

    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }
    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }
    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public Date getDepartureDate() { return departureDate; }
    public void setDepartureDate(Date departureDate) { this.departureDate = departureDate; }
    public Time getDepartureTime() { return departureTime; }
    public void setDepartureTime(Time departureTime) { this.departureTime = departureTime; }
    public Time getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(Time arrivalTime) { this.arrivalTime = arrivalTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getRequiredCrew() { return requiredCrew; }
    public void setRequiredCrew(int requiredCrew) { this.requiredCrew = requiredCrew; }
}