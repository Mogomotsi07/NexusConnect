package com.bac.airportstaffallocation.dao;

import com.bac.airportstaffallocation.config.DataSourceHelper;
import com.bac.airportstaffallocation.dao.StaffDao;
import com.bac.airportstaffallocation.model.Staff;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StaffDaoImpl implements StaffDao {

    private Staff map(ResultSet rs) throws SQLException {
        Staff s = new Staff();
        s.setStaffId(rs.getInt("staff_id"));
        s.setStaffNumber(rs.getString("staff_number"));
        s.setFullName(rs.getString("fullname"));
        s.setEmail(rs.getString("email"));
        s.setPhone(rs.getString("phone"));
        s.setRole(rs.getString("role"));
        s.setDepartment(rs.getString("department"));
        s.setStatus(rs.getString("status"));
        return s;
    }

    @Override
    public List<Staff> findAll() {
        List<Staff> list = new ArrayList<>();
        String sql = "SELECT * FROM staff ORDER BY staff_number";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public Staff findById(int id) {
        String sql = "SELECT * FROM staff WHERE staff_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public Staff findByStaffNumber(String staffNumber) {
        String sql = "SELECT * FROM staff WHERE staff_number=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, staffNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public Staff findByEmail(String email) {
        String sql = "SELECT * FROM staff WHERE email=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Staff> search(String keyword) {
        List<Staff> list = new ArrayList<>();
        String sql = "SELECT * FROM staff WHERE fullname LIKE ? OR staff_number LIKE ? OR role LIKE ?";
        String like = "%" + keyword + "%";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public void create(Staff s) {
        String sql = "INSERT INTO staff (staff_number, fullname, email, phone, role, department, status) VALUES (?,?,?,?,?,?,?)";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, s.getStaffNumber());
            ps.setString(2, s.getFullName());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getPhone());
            ps.setString(5, s.getRole());
            ps.setString(6, s.getDepartment());
            ps.setString(7, s.getStatus());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void update(Staff s) {
        String sql = "UPDATE staff SET staff_number=?, fullname=?, email=?, phone=?, role=?, department=?, status=? WHERE staff_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, s.getStaffNumber());
            ps.setString(2, s.getFullName());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getPhone());
            ps.setString(5, s.getRole());
            ps.setString(6, s.getDepartment());
            ps.setString(7, s.getStatus());
            ps.setInt(8, s.getStaffId());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM staff WHERE staff_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public int countOpenAssignments(int staffId) {
        String sql = "SELECT COUNT(*) FROM assignments WHERE staff_id=? AND status='OPEN'";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return 0;
    }
}