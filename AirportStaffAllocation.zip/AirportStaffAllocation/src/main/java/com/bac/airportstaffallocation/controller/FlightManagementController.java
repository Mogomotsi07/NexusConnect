package com.bac.airportstaffallocation.controller;

import com.bac.airportstaffallocation.dao.FlightDao;
import com.bac.airportstaffallocation.dao.FlightDaoImpl;
import com.bac.airportstaffallocation.exception.ValidationException;
import com.bac.airportstaffallocation.model.Flight;
import com.bac.airportstaffallocation.service.FlightService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;

@WebServlet("/FlightManagementController")
public class FlightManagementController extends HttpServlet {
    private final FlightDao dao = new FlightDaoImpl();
    private final FlightService service = new FlightService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "list" -> {
                String q = request.getParameter("q");
                request.setAttribute("flights",
                        (q == null || q.isBlank()) ? dao.findAll() : dao.search(q));
                request.getRequestDispatcher("/WEB-INF/views/flights/list.jsp")
                        .forward(request, response);
            }
            case "add" -> request.getRequestDispatcher("/WEB-INF/views/flights/add.jsp")
                    .forward(request, response);
            case "edit" -> {
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("flight", dao.findById(id));
                request.getRequestDispatcher("/WEB-INF/views/flights/edit.jsp")
                        .forward(request, response);
            }
            case "delete-confirm" -> {
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("flight", dao.findById(id));
                request.getRequestDispatcher("/WEB-INF/views/flights/delete-confirm.jsp")
                        .forward(request, response);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("create".equals(action) || "update".equals(action)) {
                Flight f = new Flight();
                if ("update".equals(action))
                    f.setFlightId(Integer.parseInt(request.getParameter("id")));
                f.setFlightNumber(request.getParameter("flightNumber"));
                f.setOrigin(request.getParameter("origin"));
                f.setDestination(request.getParameter("destination"));
                f.setDepartureDate(Date.valueOf(request.getParameter("departureDate")));
                f.setDepartureTime(Time.valueOf(request.getParameter("departureTime") + ":00"));
                f.setArrivalTime(Time.valueOf(request.getParameter("arrivalTime") + ":00"));
                f.setStatus(request.getParameter("status"));
                f.setRequiredCrew(Integer.parseInt(request.getParameter("requiredCrew")));

                if ("create".equals(action)) service.validateAndCreate(f);
                else service.validateAndUpdate(f);

                response.sendRedirect(request.getContextPath() + "/FlightManagementController?action=list");
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                service.delete(id);
                response.sendRedirect(request.getContextPath() + "/FlightManagementController?action=list");
            }
        } catch (ValidationException e) {
            request.setAttribute("errors", e.getErrors());
            String id = request.getParameter("id");
            if (id != null && !id.isBlank())
                request.setAttribute("flight", dao.findById(Integer.parseInt(id)));
            request.getRequestDispatcher("/WEB-INF/views/flights/" +
                    ("create".equals(action) ? "add" : "edit") + ".jsp").forward(request, response);
        } catch (IllegalArgumentException e) {
            request.setAttribute("errors",
                    java.util.Map.of("general", "Invalid date or time format."));
            request.getRequestDispatcher("/WEB-INF/views/flights/" +
                    ("create".equals(action) ? "add" : "edit") + ".jsp").forward(request, response);
        }
    }
}