package com.bac.airportstaffallocation.service;


import com.bac.airportstaffallocation.dao.AssignmentDao;
import com.bac.airportstaffallocation.dao.FlightDao;
import com.bac.airportstaffallocation.dao.StaffDao;
import com.bac.airportstaffallocation.dao.AssignmentDaoImpl;
import com.bac.airportstaffallocation.dao.FlightDaoImpl;
import com.bac.airportstaffallocation.dao.StaffDaoImpl;
import com.bac.airportstaffallocation.exception.AssignmentException;
import com.bac.airportstaffallocation.model.Assignment;
import com.bac.airportstaffallocation.model.Flight;
import com.bac.airportstaffallocation.model.Staff;

import java.util.List;

public class AssignmentService {

    // ===== Business rule constants =====
    public static final int MAX_OPEN_ASSIGNMENTS_PER_STAFF = 3;

    private final AssignmentDao assignmentDao = new AssignmentDaoImpl();
    private final StaffDao staffDao = new StaffDaoImpl();
    private final FlightDao flightDao = new FlightDaoImpl();

    /**
     * Assign staff to flight, enforcing the 5 business rules.
     */
    public void assign(int staffId, int flightId, String roleOnFlight) throws AssignmentException {
        Staff staff = staffDao.findById(staffId);
        Flight flight = flightDao.findById(flightId);

        // Rule 1: Staff and flight must exist
        if (staff == null) throw new AssignmentException("Staff member does not exist.");
        if (flight == null) throw new AssignmentException("Flight does not exist.");

        // Rule 2: Staff must be active
        if (!"Active".equalsIgnoreCase(staff.getStatus())) {
            throw new AssignmentException(staff.getFullName() + " is inactive and cannot be assigned.");
        }

        // Rule 3: Flight must be scheduled (not cancelled / departed / arrived)
        if (!"Scheduled".equalsIgnoreCase(flight.getStatus())) {
            throw new AssignmentException("Flight " + flight.getFlightNumber() +
                    " is not open for assignment (status: " + flight.getStatus() + ").");
        }

        // Rule 4: Maximum 3 open assignments per staff
        int open = assignmentDao.countOpenByStaff(staffId);
        if (open >= MAX_OPEN_ASSIGNMENTS_PER_STAFF) {
            throw new AssignmentException(staff.getFullName() + " already has " +
                    MAX_OPEN_ASSIGNMENTS_PER_STAFF + " open assignments. " +
                    "Complete one before assigning another.");
        }

        // Rule 5: Cannot assign more crew than the flight requires, and no duplicate
        int assigned = assignmentDao.countOpenByFlight(flightId);
        if (assigned >= flight.getRequiredCrew()) {
            throw new AssignmentException("Flight " + flight.getFlightNumber() +
                    " already has the required " + flight.getRequiredCrew() + " crew assigned.");
        }
        if (assignmentDao.hasOpenAssignment(staffId, flightId)) {
            throw new AssignmentException(staff.getFullName() +
                    " is already assigned to flight " + flight.getFlightNumber() + ".");
        }

        assignmentDao.create(staffId, flightId, roleOnFlight);
    }

    /**
     * Staff completes / is released from an assignment.
     */
    public void complete(int staffId, int assignmentId) throws AssignmentException {
        Assignment a = assignmentDao.findById(assignmentId);
        if (a == null) throw new AssignmentException("Assignment does not exist.");
        if (a.getStaffId() != staffId)
            throw new AssignmentException("Invalid request: this assignment belongs to another staff member.");
        if (!"OPEN".equals(a.getStatus()))
            throw new AssignmentException("Assignment is not open.");

        assignmentDao.markCompleted(assignmentId);
    }

    /**
     * Librarian/admin cancels an assignment.
     */
    public void cancel(int assignmentId) throws AssignmentException {
        Assignment a = assignmentDao.findById(assignmentId);
        if (a == null) throw new AssignmentException("Assignment does not exist.");
        if (!"OPEN".equals(a.getStatus()))
            throw new AssignmentException("Only OPEN assignments can be cancelled.");
        assignmentDao.cancel(assignmentId);
    }

    public List<Assignment> openByStaff(int staffId) {
        return assignmentDao.findOpenByStaff(staffId);
    }

    public List<Assignment> historyByStaff(int staffId) {
        return assignmentDao.findHistoryByStaff(staffId);
    }

    public List<Assignment> openByFlight(int flightId) {
        return assignmentDao.findOpenByFlight(flightId);
    }
}