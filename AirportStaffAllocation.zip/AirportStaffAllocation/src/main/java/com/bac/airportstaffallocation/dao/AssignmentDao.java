package com.bac.airportstaffallocation.dao;

import com.bac.airportstaffallocation.model.Assignment;
import java.util.List;

public interface AssignmentDao {
    void create(int staffId, int flightId, String roleOnFlight);
    void markCompleted(int assignmentId);
    void cancel(int assignmentId);
    int countOpenByStaff(int staffId);
    int countOpenByFlight(int flightId);
    List<Assignment> findOpenByStaff(int staffId);
    List<Assignment> findHistoryByStaff(int staffId);
    List<Assignment> findOpenByFlight(int flightId);
    boolean hasOpenAssignment(int staffId, int flightId);
    Assignment findById(int assignmentId);
}