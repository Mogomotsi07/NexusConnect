package com.bac.airportstaffallocation.controller;

import com.bac.airportstaffallocation.dao.StaffDao;
import com.bac.airportstaffallocation.dao.StaffDaoImpl;
import com.bac.airportstaffallocation.exception.ValidationException;
import com.bac.airportstaffallocation.model.Staff;
import com.bac.airportstaffallocation.service.StaffService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/StaffManagementController")
public class StaffManagementController extends HttpServlet {
    private final StaffDao dao = new StaffDaoImpl();
    private final StaffService service = new StaffService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "list" -> {
                String q = request.getParameter("q");
                request.setAttribute("staffList",
                        (q == null || q.isBlank()) ? dao.findAll() : dao.search(q));
                request.getRequestDispatcher("/WEB-INF/views/staff/list.jsp").forward(request, response);
            }
            case "add" -> request.getRequestDispatcher("/WEB-INF/views/staff/add.jsp")
                    .forward(request, response);
            case "edit" -> {
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("staff", dao.findById(id));
                request.getRequestDispatcher("/WEB-INF/views/staff/edit.jsp")
                        .forward(request, response);
            }
            case "delete-confirm" -> {
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("staff", dao.findById(id));
                request.getRequestDispatcher("/WEB-INF/views/staff/delete-confirm.jsp")
                        .forward(request, response);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("create".equals(action) || "update".equals(action)) {
                Staff s = new Staff();
                if ("update".equals(action))
                    s.setStaffId(Integer.parseInt(request.getParameter("id")));
                s.setStaffNumber(request.getParameter("staffNumber"));
                s.setFullName(request.getParameter("fullName"));
                s.setEmail(request.getParameter("email"));
                s.setPhone(request.getParameter("phone"));
                s.setRole(request.getParameter("role"));
                s.setDepartment(request.getParameter("department"));
                s.setStatus(request.getParameter("status"));

                if ("create".equals(action)) service.validateAndCreate(s);
                else service.validateAndUpdate(s);

                response.sendRedirect(request.getContextPath() + "/StaffManagementController?action=list");
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                service.delete(id);
                response.sendRedirect(request.getContextPath() + "/StaffManagementController?action=list");
            }
        } catch (ValidationException e) {
            request.setAttribute("errors", e.getErrors());
            String id = request.getParameter("id");
            if (id != null && !id.isBlank())
                request.setAttribute("staff", dao.findById(Integer.parseInt(id)));
            request.getRequestDispatcher("/WEB-INF/views/staff/" +
                    ("create".equals(action) ? "add" : "edit") + ".jsp").forward(request, response);
        }
    }
}