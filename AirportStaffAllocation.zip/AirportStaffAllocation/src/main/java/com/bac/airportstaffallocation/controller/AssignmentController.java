package com.bac.airportstaffallocation.controller;

import com.bac.airportstaffallocation.dao.FlightDao;
import com.bac.airportstaffallocation.dao.StaffDao;
import com.bac.airportstaffallocation.dao.FlightDaoImpl;
import com.bac.airportstaffallocation.dao.StaffDaoImpl;
import com.bac.airportstaffallocation.exception.AssignmentException;
import com.bac.airportstaffallocation.service.AssignmentService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/AssignmentController")
public class AssignmentController extends HttpServlet {
    private final AssignmentService service = new AssignmentService();
    private final StaffDao staffDao = new StaffDaoImpl();
    private final FlightDao flightDao = new FlightDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "new";

        switch (action) {
            case "new" -> {
                request.setAttribute("staffList", staffDao.findAll());
                request.setAttribute("flights", flightDao.findAll());
                request.getRequestDispatcher("/WEB-INF/views/assignments/my-assignments.jsp")
                        .forward(request, response);
            }
            case "flight-crew" -> {
                int flightId = Integer.parseInt(request.getParameter("flightId"));
                request.setAttribute("assignments", service.openByFlight(flightId));
                request.setAttribute("flight", flightDao.findById(flightId));
                request.getRequestDispatcher("/WEB-INF/views/assignments/my-assignments.jsp")
                        .forward(request, response);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action) {
                case "create" -> {
                    int staffId = Integer.parseInt(request.getParameter("staffId"));
                    int flightId = Integer.parseInt(request.getParameter("flightId"));
                    String roleOnFlight = request.getParameter("roleOnFlight");
                    service.assign(staffId, flightId, roleOnFlight);
                }
                case "complete" -> {
                    int staffId = Integer.parseInt(request.getParameter("staffId"));
                    int assignmentId = Integer.parseInt(request.getParameter("assignmentId"));
                    service.complete(staffId, assignmentId);
                }
                case "cancel" -> {
                    int assignmentId = Integer.parseInt(request.getParameter("assignmentId"));
                    service.cancel(assignmentId);
                }
            }
            response.sendRedirect(request.getContextPath() + "/CatalogueController");
        } catch (AssignmentException e) {
            request.getSession().setAttribute("errorMsg", e.getMessage());
            response.sendRedirect(request.getContextPath() + "/CatalogueController");
        } catch (Exception e) {
            response.sendError(500, "Invalid Request");
        }
    }
}