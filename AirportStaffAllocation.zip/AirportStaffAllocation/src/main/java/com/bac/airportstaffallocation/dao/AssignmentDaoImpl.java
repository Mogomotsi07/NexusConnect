package com.bac.airportstaffallocation.dao;

import com.bac.airportstaffallocation.config.DataSourceHelper;
import com.bac.airportstaffallocation.dao.AssignmentDao;
import com.bac.airportstaffallocation.model.Assignment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AssignmentDaoImpl implements AssignmentDao {

    @Override
    public void create(int staffId, int flightId, String roleOnFlight) {
        String sql = "INSERT INTO assignments (staff_id, flight_id, assigned_on, role_on_flight, status) " +
                "VALUES (?, ?, NOW(), ?, 'OPEN')";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            ps.setInt(2, flightId);
            ps.setString(3, roleOnFlight);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void markCompleted(int assignmentId) {
        String sql = "UPDATE assignments SET status='COMPLETED', completed_on=NOW() WHERE assignment_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void cancel(int assignmentId) {
        String sql = "UPDATE assignments SET status='CANCELLED', completed_on=NOW() WHERE assignment_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public int countOpenByStaff(int staffId) {
        String sql = "SELECT COUNT(*) FROM assignments WHERE staff_id=? AND status='OPEN'";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return 0;
    }

    @Override
    public int countOpenByFlight(int flightId) {
        String sql = "SELECT COUNT(*) FROM assignments WHERE flight_id=? AND status='OPEN'";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return 0;
    }

    @Override
    public List<Assignment> findOpenByStaff(int staffId) {
        return findAssignments(staffId, true, "OPEN");
    }

    @Override
    public List<Assignment> findHistoryByStaff(int staffId) {
        return findAssignments(staffId, false, null);
    }

    @Override
    public List<Assignment> findOpenByFlight(int flightId) {
        List<Assignment> list = new ArrayList<>();
        String sql = "SELECT a.*, s.fullname AS staff_name, f.flight_number " +
                "FROM assignments a " +
                "JOIN staff s ON a.staff_id = s.staff_id " +
                "JOIN flights f ON a.flight_id = f.flight_id " +
                "WHERE a.flight_id = ? AND a.status = 'OPEN'";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    private List<Assignment> findAssignments(int staffId, boolean openOnly, String status) {
        List<Assignment> list = new ArrayList<>();
        String sql = "SELECT a.*, s.fullname AS staff_name, f.flight_number " +
                "FROM assignments a " +
                "JOIN staff s ON a.staff_id = s.staff_id " +
                "JOIN flights f ON a.flight_id = f.flight_id " +
                "WHERE a.staff_id = ?";
        if (openOnly && status != null) sql += " AND a.status = ?";
        if (!openOnly) sql += " AND a.status <> 'OPEN'";
        sql += " ORDER BY a.assigned_on DESC";

        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            if (openOnly && status != null) ps.setString(2, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean hasOpenAssignment(int staffId, int flightId) {
        String sql = "SELECT 1 FROM assignments WHERE staff_id=? AND flight_id=? AND status='OPEN'";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            ps.setInt(2, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public Assignment findById(int assignmentId) {
        String sql = "SELECT a.*, s.fullname AS staff_name, f.flight_number " +
                "FROM assignments a " +
                "JOIN staff s ON a.staff_id = s.staff_id " +
                "JOIN flights f ON a.flight_id = f.flight_id " +
                "WHERE a.assignment_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, assignmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    private Assignment map(ResultSet rs) throws SQLException {
        Assignment a = new Assignment();
        a.setAssignmentId(rs.getInt("assignment_id"));
        a.setStaffId(rs.getInt("staff_id"));
        a.setFlightId(rs.getInt("flight_id"));
        a.setAssignedOn(rs.getTimestamp("assigned_on"));
        a.setCompletedOn(rs.getTimestamp("completed_on"));
        a.setRoleOnFlight(rs.getString("role_on_flight"));
        a.setStatus(rs.getString("status"));
        try { a.setStaffName(rs.getString("staff_name")); } catch (SQLException ignored) {}
        try { a.setFlightNumber(rs.getString("flight_number")); } catch (SQLException ignored) {}
        return a;
    }
}