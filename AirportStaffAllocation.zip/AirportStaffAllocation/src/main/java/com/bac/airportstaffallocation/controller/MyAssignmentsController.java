package com.bac.airportstaffallocation.controller;

import com.bac.airportstaffallocation.dao.StaffDao;
import com.bac.airportstaffallocation.dao.StaffDaoImpl;
import com.bac.airportstaffallocation.model.Staff;
import com.bac.airportstaffallocation.service.AssignmentService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/MyAssignmentsController")
public class MyAssignmentsController extends HttpServlet {
    private final AssignmentService service = new AssignmentService();
    private final StaffDao staffDao = new StaffDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Staff s = staffDao.findByEmail(request.getRemoteUser());
        if (s == null) {
            // fall back to staff_number if usernames are staff numbers
            s = staffDao.findByStaffNumber(request.getRemoteUser());
        }
        if (s == null) {
            response.sendError(403, "No staff record linked to logged in user.");
            return;
        }

        request.setAttribute("staff", s);
        request.setAttribute("openAssignments", service.openByStaff(s.getStaffId()));
        request.setAttribute("history", service.historyByStaff(s.getStaffId()));
        request.setAttribute("maxAssignments", AssignmentService.MAX_OPEN_ASSIGNMENTS_PER_STAFF);

        String err = (String) request.getSession().getAttribute("errorMsg");
        if (err != null) {
            request.setAttribute("error", err);
            request.getSession().removeAttribute("errorMsg");
        }

        request.getRequestDispatcher("/WEB-INF/views/assignments/my-assignments.jsp")
                .forward(request, response);
    }
}