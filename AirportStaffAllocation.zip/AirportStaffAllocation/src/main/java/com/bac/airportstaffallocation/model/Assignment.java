package com.bac.airportstaffallocation.model;

import java.sql.Timestamp;

public class Assignment {
    private int assignmentId;
    private int staffId;
    private int flightId;
    private Timestamp assignedOn;
    private Timestamp completedOn;
    private String roleOnFlight;
    private String status; // OPEN / COMPLETED / CANCELLED

    // UI display fields
    private String staffName;
    private String flightNumber;

    public Assignment() {}

    public int getAssignmentId() { return assignmentId; }
    public void setAssignmentId(int assignmentId) { this.assignmentId = assignmentId; }
    public int getStaffId() { return staffId; }
    public void setStaffId(int staffId) { this.staffId = staffId; }
    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }
    public Timestamp getAssignedOn() { return assignedOn; }
    public void setAssignedOn(Timestamp assignedOn) { this.assignedOn = assignedOn; }
    public Timestamp getCompletedOn() { return completedOn; }
    public void setCompletedOn(Timestamp completedOn) { this.completedOn = completedOn; }
    public String getRoleOnFlight() { return roleOnFlight; }
    public void setRoleOnFlight(String roleOnFlight) { this.roleOnFlight = roleOnFlight; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getStaffName() { return staffName; }
    public void setStaffName(String staffName) { this.staffName = staffName; }
    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }
}