package com.bac.airportstaffallocation.service;

import com.bac.airportstaffallocation.dao.StaffDao;
import com.bac.airportstaffallocation.dao.StaffDaoImpl;
import com.bac.airportstaffallocation.exception.ValidationException;
import com.bac.airportstaffallocation.model.Staff;

public class StaffService {

    private final StaffDao staffDao = new StaffDaoImpl();

    public void validateAndCreate(Staff s) throws ValidationException {
        validateCommon(s);
        staffDao.create(s);
    }

    public void validateAndUpdate(Staff s) throws ValidationException {
        validateCommon(s);
        staffDao.update(s);
    }

    public void delete(int staffId) throws ValidationException {
        Staff s = staffDao.findById(staffId);
        if (s == null) throw new ValidationException("error", "Staff not found.");

        if (staffDao.countOpenAssignments(staffId) > 0) {
            throw new ValidationException("error",
                    s.getFullName() + " cannot be deleted because they have open assignments.");
        }
        staffDao.delete(staffId);
    }

    private void validateCommon(Staff s) throws ValidationException {
        if (s.getStaffNumber() == null || s.getStaffNumber().isBlank())
            throw new ValidationException("staffNumber", "Staff number is required.");
        if (s.getFullName() == null || s.getFullName().isBlank())
            throw new ValidationException("fullName", "Full name is required.");
        if (s.getEmail() == null || !s.getEmail().contains("@"))
            throw new ValidationException("email", "Valid email is required.");
        if (s.getRole() == null || s.getRole().isBlank())
            throw new ValidationException("role", "Role is required.");
        if (s.getDepartment() == null || s.getDepartment().isBlank())
            throw new ValidationException("department", "Department is required.");
        if (s.getStatus() == null || s.getStatus().isBlank())
            s.setStatus("Active");

        Staff checkNum = staffDao.findByStaffNumber(s.getStaffNumber());
        if (checkNum != null && checkNum.getStaffId() != s.getStaffId())
            throw new ValidationException("staffNumber", "Staff number already in use.");

        Staff checkEmail = staffDao.findByEmail(s.getEmail());
        if (checkEmail != null && checkEmail.getStaffId() != s.getStaffId())
            throw new ValidationException("email", "Email already in use.");
    }
}