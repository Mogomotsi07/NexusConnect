package com.bac.airportstaffallocation.dao;


import com.bac.airportstaffallocation.model.Staff;
import java.util.List;

public interface StaffDao {
    List<Staff> findAll();
    Staff findById(int id);
    Staff findByStaffNumber(String staffNumber);
    Staff findByEmail(String email);
    List<Staff> search(String keyword);
    void create(Staff staff);
    void update(Staff staff);
    void delete(int id);
    int countOpenAssignments(int staffId);
}