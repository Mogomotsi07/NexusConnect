package com.bac.airportstaffallocation.dao;


import com.bac.airportstaffallocation.model.Flight;
import java.util.List;

public interface FlightDao {
    List<Flight> findAll();
    Flight findById(int id);
    Flight findByFlightNumber(String flightNumber);
    List<Flight> search(String keyword);
    void create(Flight flight);
    void update(Flight flight);
    void delete(int id);
    int countOpenAssignments(int flightId);
}