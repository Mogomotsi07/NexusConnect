package com.bac.airportstaffallocation.model;

public class Staff {
    private int staffId;
    private String staffNumber;
    private String fullName;
    private String email;
    private String phone;
    private String role;       // e.g. Pilot, Cabin Crew, Ground Ops
    private String department;
    private String status;     // Active / Inactive

    public Staff() {}

    public Staff(int staffId, String staffNumber, String fullName, String email,
                 String phone, String role, String department, String status) {
        this.staffId = staffId;
        this.staffNumber = staffNumber;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.role = role;
        this.department = department;
        this.status = status;
    }

    public int getStaffId() { return staffId; }
    public void setStaffId(int staffId) { this.staffId = staffId; }
    public String getStaffNumber() { return staffNumber; }
    public void setStaffNumber(String staffNumber) { this.staffNumber = staffNumber; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}