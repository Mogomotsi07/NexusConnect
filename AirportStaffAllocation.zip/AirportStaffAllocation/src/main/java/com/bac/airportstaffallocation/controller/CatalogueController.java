package com.bac.airportstaffallocation.controller;


import com.bac.airportstaffallocation.dao.FlightDao;
import com.bac.airportstaffallocation.dao.FlightDaoImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/CatalogueController")
public class CatalogueController extends HttpServlet {
    private final FlightDao flightDao = new FlightDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String q = request.getParameter("q");
        request.setAttribute("flights",
                (q == null || q.isBlank()) ? flightDao.findAll() : flightDao.search(q));
        request.getRequestDispatcher("/WEB-INF/views/catalogue.jsp").forward(request, response);
    }
}